#pragma once

class Auth {
public:
     void authThread();
};