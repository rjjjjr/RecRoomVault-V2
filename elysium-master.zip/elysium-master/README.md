# Elysium
I wrote this over a year ago, you can clown on the auth it was bad haha. This project was made following [this tutorial](https://www.youtube.com/watch?v=CPFGgRqTMd4&ab_channel=KC).