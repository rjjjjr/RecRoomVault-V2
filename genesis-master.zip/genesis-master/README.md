> # **Genesis**
Internal made by TheOneAboveAll back in 2019, pretty sure it's for Mono and not IL2CPP.