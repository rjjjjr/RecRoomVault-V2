﻿// Decompiled with JetBrains decompiler
// Type: AC.CPP.E.AddressAttribute
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

using System;

namespace AC.CPP.E
{
  public class AddressAttribute : Attribute
  {
    public string RVA;
    public string Offset;
    public string VA;
    public string Slot;
  }
}
