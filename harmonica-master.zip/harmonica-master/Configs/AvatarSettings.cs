﻿// Decompiled with JetBrains decompiler
// Type: Configs.AvatarSettings
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

namespace Configs
{
  public class AvatarSettings
  {
    public string OutfitSelection;
    public string HairColour;
    public string SkinColour;
  }
}
