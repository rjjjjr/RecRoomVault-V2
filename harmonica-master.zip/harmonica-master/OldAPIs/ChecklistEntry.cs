﻿// Decompiled with JetBrains decompiler
// Type: OldAPIs.ChecklistEntry
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

namespace OldAPIs
{
  public class ChecklistEntry
  {
    public int Order { get; set; }

    public int Objective { get; set; }

    public int Count { get; set; }

    public int CreditAmount { get; set; }
  }
}
