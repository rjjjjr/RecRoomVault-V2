﻿// Decompiled with JetBrains decompiler
// Type: OldAPIs.OtherPlayerEvent
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

namespace OldAPIs
{
  internal class OtherPlayerEvent
  {
    public playerEvent PlayerEvent { get; set; }

    public playerEventResponse PlayerEventResponse { get; set; }
  }
}
