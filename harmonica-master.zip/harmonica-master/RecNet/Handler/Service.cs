﻿// Decompiled with JetBrains decompiler
// Type: RecNet.Handler.Service
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

namespace RecNet.Handler
{
  public enum Service
  {
    NAME_SERVER,
    API,
    AUTH,
    CDN,
    CHAT,
    CLUBS,
    COMMERCE,
    IMAGES,
    LEADERBOARD,
    LINK,
    MATCHMAKING,
    NOTIFICATIONS,
    ROOM_COMMENTS,
    ROOMS,
    STORAGE,
    WWW,
  }
}
