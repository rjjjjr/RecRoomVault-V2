﻿// Decompiled with JetBrains decompiler
// Type: RecNet.IncentivizedItems
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

using System.Collections.Generic;

namespace RecNet
{
  internal class IncentivizedItems
  {
    public static List<OutfitItems.AvatarItem> CustomItems = new List<OutfitItems.AvatarItem>()
    {
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "01d0fc12-3ebe-42e1-8caa-5513a40436c1,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bat Bowtie - Available until 10/25",
        Tooltip = "Available until 10/25",
        PlatformMask = -1,
        Rarity = 50
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "de0ac50d-2adb-4114-bd2e-68953b13d706,uCA4tnv9Mk2mX-NnFlj2Mg,NvlKJFz4IkKDliVOJKJYhA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Hallow's Blazer (Pinstripe) - Available until 10/25",
        Tooltip = "Available until 10/25",
        PlatformMask = -1,
        Rarity = 50
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "h_To9WQYdEusYQxlbMmMmQ,hT7nSD7Ts06F_1SNlOMLwg,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Dracula Cape",
        Tooltip = "Quest_Dracula_Cape",
        PlatformMask = -1,
        Rarity = 50
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "f2db0ec1-e536-4218-8385-dc6913941880,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cosmic Hero Glove",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "2c679f89-c76e-4cfb-94e9-448c8fd44d55,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Shirt",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "50c9c6f8-2963-4ef3-95d5-e999a898269f,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Gloves",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "274cb9b2-2f59-47ea-9a8d-a5b656d148c6,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Helmet",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "4308da04-af84-40bb-845a-7a9e1a2726ec,46970903-9799-4d25-b90a-7162c1f5dbef,c2052d8c-fbcd-4462-8f08-bcf5b3dfde2f,",
        AvatarItemType = new int?(0),
        FriendlyName = "Mobster Suit (Fashion)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "08d56627-4500-4724-8692-a23c96ddb3ec,46970903-9799-4d25-b90a-7162c1f5dbef,05cff8b8-d437-485a-b4b8-41d35becd022,",
        AvatarItemType = new int?(0),
        FriendlyName = "Mobster Cuffs (Fashion)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "193a3bf9-abc0-4d78-8d63-92046908b1c5,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Emo Hair",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "b861e5f3-fc6d-43b3-9861-c1b45cb493a8,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bishop Hair",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "2786fc22-3d6c-440d-afcc-15890c061577,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bee Hat",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "abc25091-ed5f-4c72-9364-fffeef1bc239,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bishop Gloves",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6930ce13-4be4-4ab9-9817-667bd261ffc3,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bishop Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3739a9e1-6dfa-45d2-af54-cc83a58d436a,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cosmic Hero Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "GAWURQSqrEW4G5slrPMgZA,gwLiwmqBIk6glFxvaTzxeA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "The Dude Sweater",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "uubY_Cn9A0-Ww4lsIRCF6w,vDSlMnayzEqWXwT-lkcKSA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Dracula Medal",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = "Quest_Dracula_Medal"
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "jUpFzO5MPEGTbS-E0a99Nw,JWanxvOHyESg9F_HlmTOfA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Dracula Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = "Quest_Dracula_Tuxedo"
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "5154be09-bb8a-4917-95a0-51c91b6a4e09e,515dfc36-7f7b-47bc-abee-380d68f41be6,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Shirt 1 (Conductor)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "5873814e-c9a1-4042-b96d-2aa0e0d52e2ae,587ca2bb-dd42-42bf-833f-4e2a97349866,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Shirt 2 (International Thief)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d12e5738-00c7-47e7-9334-8399eec5aa89,d15139de-5e57-423b-b8da-335ad7a4df5a,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Hat 2 (International Thief)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "7dc6c916-b887-4929-93b5-dcea3022e6a9,7dd6f7b0-7ba0-429f-a04f-e32d3a79ee61,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Hat 3 (Top Hat)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d86e2e65-5d87-466d-b885-8c52ac2eeeb0e,d8f408f0-78f5-4e8a-b42a-e7b09632d1fd,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Hat 4 (Sea Captain)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "KNZ1DvCLC0WHyH4opYAXtw,KPmC_wyX_ECe7fdKwoLMGg,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Contest Hat 5 (Visor)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "7ea796bf-f552-4da8-8f68-a87c4896c8e6,7LSm-xCYakmgcAr--Fn-JA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears with Earing",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d6b0a1e7-e918-43e5-8191-3a8d9d01df7c,e5635772-4e84-4b30-b77f-4a1196cb599b,b1ea158d-1663-4db1-bb09-9847f6e9d1e6,",
        AvatarItemType = new int?(0),
        FriendlyName = "Hockey Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,ba6b6e1a-a09a-4ba0-9523-552869f03336,0440f08f-ef1d-49d8-942b-523056e8bb45,d461ca71-45c9-415e-8e09-ba93e8d73450",
        AvatarItemType = new int?(0),
        FriendlyName = "Happy Trees",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,815138e6-b0dc-459c-9538-20f5bbd37d6b,0440f08f-ef1d-49d8-942b-523056e8bb45,hHhjZeLcaUGN1OyFoYHznw",
        AvatarItemType = new int?(0),
        FriendlyName = "Happy Trees (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,TtncjvYcK0qHqWN-IMMoqg,0440f08f-ef1d-49d8-942b-523056e8bb45,75162f12-44e7-499f-bc6c-9b0612e9164b",
        AvatarItemType = new int?(0),
        FriendlyName = "Class of 2017 (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,6kPcLZtEqU2Hs4yBFvc_sA,0440f08f-ef1d-49d8-942b-523056e8bb45,NxMm0sSBdUatynU16o0_Zw",
        AvatarItemType = new int?(0),
        FriendlyName = "Class of 2018",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,6kPcLZtEqU2Hs4yBFvc_sA,0440f08f-ef1d-49d8-942b-523056e8bb45,br9hzhDoZUmIevgl7SJkmg",
        AvatarItemType = new int?(0),
        FriendlyName = "Class of 2019",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "7e6e24b6-6f9c-4315-b457-73eba52d824c,7ea796bf-f552-4da8-8f68-a87c4896c8e6,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Pumpkin Glove",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "84600de6-93fc-4a89-961e-1f18f4b80643e,84cd594c-1cd8-4b4d-8409-85c8fd5fb02a,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Pumpkin Glove",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "84600de6-93fc-4a89-961e-1f18f4b80643e,84cd594c-1cd8-4b4d-8409-85c8fd5fb02a,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Pumpkin Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "9ad40310-7cb9-473d-920c-5c18d7972030,9b5406c4-8589-47e4-9f69-4fa4733615e7,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Pumpkin Hat",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "M9weaekvIUimiJSVJqZl-w,mfFLpKQRE0anhrmeUvW0bA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Tutorial Cap",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "MJQiQ3LATEOymxCC8wfSjw,MJQiQ3LATEOymxCC8wfSjw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Tutorial Gown 2",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "O8VqC11xNkSKpDh6Omp_0w,oRUh266ohkWQil14uxcEdQ,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Tutorial Sash 3",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "oRUh266ohkWQil14uxcEdQ,OTnfT-4NQU6Gd_iVPDx8eg,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Mummy Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "Lli8-aqt1EmCmyXwBRQaYA,m5Plrduzr0yj_9mTn1x3Vw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Mummy Hat",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "zpjkkb1HtUORoPaODFuuxg,ZsggwOJ8XUOGfaJltM418g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Mummy Glove",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "OTnfT-4NQU6Gd_iVPDx8eg,oYvOo47DJE-DEPlpn5xNUw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Frankenstein Hat",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "tkbHKZ9wu0W00VGeUbIaaw,tTKv7eRODka2KC_hsY2O3Q,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Frankenstein Glove",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "ZsggwOJ8XUOGfaJltM418g,_OWVy3z6iU-M3-zbQgSLig,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Frankenstein Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "37668d3d-c9f4-4bd6-81d4-a4f64ba2d61b,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bee Wings",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "bb8602d4-f91f-4e35-9c88-1cdf3a04ff0a,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bee Shirt",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "df0e06c4-8ba6-4d7a-bfb2-3759d8fe88c7,,eZGiYEx6sk2PsN39RzQwlQ,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Hoodie (Glow Green)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6a98bbb6-bbe0-4dc3-97a9-e253dc506a2b,,GXS9LQgPU0mJIEuXo_Oocw,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Gloves (Glow Geen)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "28e5dd74-7963-42cf-aa68-f8005aaf312e,,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Mask (Glow Green)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "df0e06c4-8ba6-4d7a-bfb2-3759d8fe88c7,s6DQxJ3gY0CG8L7JmcmRTQ,eZGiYEx6sk2PsN39RzQwlQ,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Hoodie",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6a98bbb6-bbe0-4dc3-97a9-e253dc506a2b,s6DQxJ3gY0CG8L7JmcmRTQ,GXS9LQgPU0mJIEuXo_Oocw,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Gloves",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "28e5dd74-7963-42cf-aa68-f8005aaf312e,s6DQxJ3gY0CG8L7JmcmRTQ,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Mask ",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "df0e06c4-8ba6-4d7a-bfb2-3759d8fe88c7,ZY0rVNemjEuEMGMjuPNZyA,eZGiYEx6sk2PsN39RzQwlQ,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Hoodie (Glow Blue)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6a98bbb6-bbe0-4dc3-97a9-e253dc506a2b,ZY0rVNemjEuEMGMjuPNZyA,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Gloves (Glow Blue)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "28e5dd74-7963-42cf-aa68-f8005aaf312e,ZY0rVNemjEuEMGMjuPNZyA,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Mask (Glow Blue)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "df0e06c4-8ba6-4d7a-bfb2-3759d8fe88c7,jhPUIkf5bkinMSsqPTK3fg,eZGiYEx6sk2PsN39RzQwlQ,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Hoodie (Glow Yellow)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6a98bbb6-bbe0-4dc3-97a9-e253dc506a2b,jhPUIkf5bkinMSsqPTK3fg,GXS9LQgPU0mJIEuXo_Oocw,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Gloves (Glow Yellow)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "28e5dd74-7963-42cf-aa68-f8005aaf312e,jhPUIkf5bkinMSsqPTK3fg,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Mask (Glow Yellow)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "df0e06c4-8ba6-4d7a-bfb2-3759d8fe88c7,DJnKyNXtuEW1tbKBFscIng,eZGiYEx6sk2PsN39RzQwlQ,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Hoodie (Glow Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "6a98bbb6-bbe0-4dc3-97a9-e253dc506a2b,DJnKyNXtuEW1tbKBFscIng,GXS9LQgPU0mJIEuXo_Oocw,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Gloves (Glow Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "28e5dd74-7963-42cf-aa68-f8005aaf312e,DJnKyNXtuEW1tbKBFscIng,DfyODsHfIESXxVjcfZmBOA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Skeleton Mask (Glow Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "b6rLwzD4NkKV7xKn9ZYVkA,Z10TTlOeW0mumezbqXKGzA,Ht0WRvpguUaLZ1tigCzCMA,",
        AvatarItemType = new int?(0),
        FriendlyName = "Hoodie (Gold)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "9656a307-0c79-4b8f-910f-e67c454faefb,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Rec Pods (Cyan)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "022ce375-ed02-479d-b87d-9d72d126bbd4,H6fcuLxeBUSY3oERFc-plA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Jack Frost Wings (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "105a5100-cb57-410f-a26b-1ee21002f067,KwhdQ1deNE6Y6jzO9vaAnQ,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Jack Frost Shirt (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "e6216087-fb37-46f1-bda4-a88c4640f339,KwhdQ1deNE6Y6jzO9vaAnQ,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Jack Frost Hat (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "e1f842c7-4ce5-4bda-8c78-5a75a6c544bf,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bat Wings Costume",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "a0a38623-2003-469a-b06f-ce451413727b,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bat Shirt Costume",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "336aeb24-33a1-4aae-82e6-4fdbd1330452,,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Bat Hat Costume",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3d5184e1-0201-4476-bf4b-4eb28190de62,37f8378b-b98c-477a-b8c9-9340772800b5,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears (Gold)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3d5184e1-0201-4476-bf4b-4eb28190de62,TtncjvYcK0qHqWN-IMMoqg,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "KNZ1DvCLC0WHyH4opYAXtw,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Space Visor (Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "KNZ1DvCLC0WHyH4opYAXtw,TtncjvYcK0qHqWN-IMMoqg,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Space Visor (Purple)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "KNZ1DvCLC0WHyH4opYAXtw,H6fcuLxeBUSY3oERFc-plA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Space Visor (Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3d5184e1-0201-4476-bf4b-4eb28190de62,H6fcuLxeBUSY3oERFc-plA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears (Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,H6fcuLxeBUSY3oERFc-plA,0440f08f-ef1d-49d8-942b-523056e8bb45,75162f12-44e7-499f-bc6c-9b0612e9164b",
        AvatarItemType = new int?(0),
        FriendlyName = "Class of 2017 (Pink)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "022ce375-ed02-479d-b87d-9d72d126bbd4,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Jack Frost Wings (Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3d5184e1-0201-4476-bf4b-4eb28190de62,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears (Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "2c679f89-c76e-4cfb-94e9-448c8fd44d55,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Shirt (Red)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "50c9c6f8-2963-4ef3-95d5-e999a898269f,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Gloves (Red)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "274cb9b2-2f59-47ea-9a8d-a5b656d148c6,yM5xRrd9OkmDGyQddwOP6g,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Helmet (Red)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,yM5xRrd9OkmDGyQddwOP6g,0440f08f-ef1d-49d8-942b-523056e8bb45,75162f12-44e7-499f-bc6c-9b0612e9164b",
        AvatarItemType = new int?(0),
        FriendlyName = "Class of 2017 (Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "KNZ1DvCLC0WHyH4opYAXtw,MJQiQ3LATEOymxCC8wfSjw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Space Visor (Dark Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "3d5184e1-0201-4476-bf4b-4eb28190de62,MJQiQ3LATEOymxCC8wfSjw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Cat Ears (Dark Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "022ce375-ed02-479d-b87d-9d72d126bbd4,MJQiQ3LATEOymxCC8wfSjw,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Jack Frost Wings (Dark Red)",
        PlatformMask = -1,
        Rarity = 0,
        Tooltip = ""
      },
      new OutfitItems.AvatarItem()
      {
        AvatarItemDesc = "50c9c6f8-2963-4ef3-95d5-e999a898269f,H6fcuLxeBUSY3oERFc-plA,,",
        AvatarItemType = new int?(0),
        FriendlyName = "Sajia Gloves (Red)",
        PlatformMask = -1,
        Rarity = 50,
        Tooltip = ""
      }
    };
  }
}
