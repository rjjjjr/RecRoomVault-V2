﻿// Decompiled with JetBrains decompiler
// Type: RecNet.Players
// Assembly: NgrokRightRoomServer, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 50707685-AB19-45DC-B196-9E24C2A59B7A
// Assembly location: C:\Users\Rohan\Desktop\Updater\Harmonica.exe

namespace RecNet
{
  public class Players
  {
    public class Reputation
    {
      public int? AccountId { get; set; }

      public bool? IsCheerful { get; set; }

      public double? Noteriety { get; set; }

      public int? SelectedCheer { get; set; }

      public int? CheerCredit { get; set; }

      public int? CheerGeneral { get; set; }

      public int? CheerHelpful { get; set; }

      public int? CheerCreative { get; set; }

      public int? CheerGreatHost { get; set; }

      public int? CheerSportsman { get; set; }
    }
  }
}
