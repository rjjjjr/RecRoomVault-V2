# Hysteria Client
This was the internal used for the client side hook in Hysteria. This project was made following [this tutorial](https://www.youtube.com/watch?v=CPFGgRqTMd4&ab_channel=KC).