#pragma once

void consoleThread();
