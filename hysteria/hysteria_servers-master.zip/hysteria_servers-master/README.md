# Hysteria Servers
MITM Servers, each folder would run on it's own server/host. Clown on the dogshit code all you like, I wrote almost none of it.