> # RockShitMin Internal
Made by rockpikmin888#8888 and his goonsquad sometime in 2023. Very shit code. Cannot recommend using this for anything other than a reference.