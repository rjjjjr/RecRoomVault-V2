#pragma once
static class MethodPointers
{
	static bool EnableMethodPointers();
	
	
	
};

