﻿using System;

namespace Nerec
{
	// Token: 0x02000139 RID: 313
	public static class IDAFIIJHJKMALNIJMH
	{
		// Token: 0x040002A2 RID: 674
		public const string Name = "Nerec";

		// Token: 0x040002A3 RID: 675
		public const string Description = "";

		// Token: 0x040002A4 RID: 676
		public const string Author = "nullable";

		// Token: 0x040002A5 RID: 677
		public const string Company = null;

		// Token: 0x040002A6 RID: 678
		public const string Version = "1.0.0";

		// Token: 0x040002A7 RID: 679
		public const string DownloadLink = null;
	}
}
