﻿using System;

namespace Nerec.Inject.Cheat
{
	// Token: 0x02000192 RID: 402
	public interface PDFNNALBNPGMIBLPFG
	{
		// Token: 0x060006C9 RID: 1737
		void DestroyExistingObjects();
	}
}
