﻿using System;

namespace Nerec.Library.Critical.ClientAuth
{
	// Token: 0x0200018E RID: 398
	public interface HMLHHOLDAFJBNAKPPD
	{
		// Token: 0x060006C0 RID: 1728
		void GenerateChallenge(byte[] serverChallenge, byte[] clientResponse);
	}
}
