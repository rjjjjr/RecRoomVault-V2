﻿using System;
using UnityEngine;

namespace Nerec.Library.Includes
{
	// Token: 0x0200016C RID: 364
	[GLOMGGIOCDALLIEGAB]
	public class AEOJIKIFPKKJCOMBAO : HCDGGMLMONJBIJBBOI
	{
		// Token: 0x06000630 RID: 1584 RVA: 0x000065EF File Offset: 0x000047EF
		public AEOJIKIFPKKJCOMBAO(MonoBehaviour monoBehaviour) : base(monoBehaviour)
		{
			this._monoBehaviour = monoBehaviour;
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x000065FF File Offset: 0x000047FF
		public bool get_UseGUILayout()
		{
			return this._monoBehaviour.useGUILayout;
		}

		// Token: 0x0400038B RID: 907
		private MonoBehaviour _monoBehaviour;
	}
}
