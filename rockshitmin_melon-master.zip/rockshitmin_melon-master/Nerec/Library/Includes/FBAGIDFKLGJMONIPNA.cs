﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000182 RID: 386
	[GLOMGGIOCDALLIEGAB]
	public class FBAGIDFKLGJMONIPNA : FFACMGPJKHNBKLCJEK, IOPBKGMNPFHIEIFCEA
	{
		// Token: 0x06000686 RID: 1670 RVA: 0x0000685E File Offset: 0x00004A5E
		public object get_Current()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool MoveNext()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0000685E File Offset: 0x00004A5E
		public void Reset()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_IsCompleted()
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_HasSucceeded()
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_HasError()
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK Then(Action thenFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK Error(Action<string> errorFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK Finally(Action finallyFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<CIICGKFCNBIEHNNICJ> ContinueWith<CIICGKFCNBIEHNNICJ>(Func<PAPGFFIAEPDMAOFCHH<CIICGKFCNBIEHNNICJ>> transformFunc, Func<string, PAPGFFIAEPDMAOFCHH<CIICGKFCNBIEHNNICJ>> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK ContinueWith(Func<FFACMGPJKHNBKLCJEK> transformFunc, Func<string, FFACMGPJKHNBKLCJEK> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<PKLHGOBODDMLCBGCKJ> Transform<PKLHGOBODDMLCBGCKJ>(Func<PKLHGOBODDMLCBGCKJ> transformFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK TransformError(Func<string, string> transformFunc)
		{
			throw new NotImplementedException();
		}
	}
}
