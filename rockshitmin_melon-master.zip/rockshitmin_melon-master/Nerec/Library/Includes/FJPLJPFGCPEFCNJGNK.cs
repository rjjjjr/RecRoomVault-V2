﻿using System;
using Il2CppPhoton.Pun;

namespace Nerec.Library.Includes
{
	// Token: 0x02000173 RID: 371
	[GLOMGGIOCDALLIEGAB]
	public class FJPLJPFGCPEFCNJGNK : AEOJIKIFPKKJCOMBAO, KEKLBJIKIJGLEPGGAB, FKEMNDNPHAGJKEFHKN
	{
		// Token: 0x06000643 RID: 1603 RVA: 0x000066C4 File Offset: 0x000048C4
		public FJPLJPFGCPEFCNJGNK(MonoBehaviourPun monoBehaviourPun) : base(monoBehaviourPun)
		{
			this._monoBehaviourPun = monoBehaviourPun;
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x000066D4 File Offset: 0x000048D4
		public bool get_HasAuthority()
		{
			return this._monoBehaviourPun.HasAuthority;
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x000066E1 File Offset: 0x000048E1
		public bool get_IsDestroyed()
		{
			return this._monoBehaviourPun.IsDestroyed;
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x000066EE File Offset: 0x000048EE
		public int get_GraphId()
		{
			return this._monoBehaviourPun.GraphId;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x000066FB File Offset: 0x000048FB
		public int get_ViewId()
		{
			return this._monoBehaviourPun.ViewId;
		}

		// Token: 0x04000390 RID: 912
		private MonoBehaviourPun _monoBehaviourPun;
	}
}
