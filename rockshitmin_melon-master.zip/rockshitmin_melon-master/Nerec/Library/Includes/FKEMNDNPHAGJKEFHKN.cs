﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000171 RID: 369
	[GLOMGGIOCDALLIEGAB]
	public interface FKEMNDNPHAGJKEFHKN
	{
		// Token: 0x0600063F RID: 1599
		bool get_HasAuthority();

		// Token: 0x06000640 RID: 1600
		bool get_IsDestroyed();

		// Token: 0x06000641 RID: 1601
		int get_GraphId();
	}
}
