﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000183 RID: 387
	[GLOMGGIOCDALLIEGAB]
	public class GLALCDFEFEMIFEJBAL<T> : PAPGFFIAEPDMAOFCHH<T>, FFACMGPJKHNBKLCJEK, IOPBKGMNPFHIEIFCEA
	{
		// Token: 0x06000694 RID: 1684 RVA: 0x0000685E File Offset: 0x00004A5E
		public object get_Current()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool MoveNext()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x0000685E File Offset: 0x00004A5E
		public void Reset()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_IsCompleted()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_HasSucceeded()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x0000685E File Offset: 0x00004A5E
		public bool get_HasError()
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<T> Then(Action thenFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<T> Error(Action<string> errorFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<T> Finally(Action finallyFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<CGJEGPIKJDMCAOCNKN> ContinueWith<CGJEGPIKJDMCAOCNKN>(Func<T, PAPGFFIAEPDMAOFCHH<CGJEGPIKJDMCAOCNKN>> transformFunc, Func<string, PAPGFFIAEPDMAOFCHH<CGJEGPIKJDMCAOCNKN>> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK ContinueWith(Func<T, FFACMGPJKHNBKLCJEK> transformFunc, Func<string, FFACMGPJKHNBKLCJEK> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<LHIBIOGEMBGILBBODH> Transform<LHIBIOGEMBGILBBODH>(Func<T, LHIBIOGEMBGILBBODH> transformFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<T> TransformError(Func<string, string> transformFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<T> Then(Action<T> thenFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x00006865 File Offset: 0x00004A65
		FFACMGPJKHNBKLCJEK FFACMGPJKHNBKLCJEK.Then(Action thenFunc)
		{
			return this.Then(thenFunc);
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0000686E File Offset: 0x00004A6E
		FFACMGPJKHNBKLCJEK FFACMGPJKHNBKLCJEK.Error(Action<string> errorFunc)
		{
			return this.Error(errorFunc);
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00006877 File Offset: 0x00004A77
		FFACMGPJKHNBKLCJEK FFACMGPJKHNBKLCJEK.Finally(Action finallyFunc)
		{
			return this.Finally(finallyFunc);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<NMEFOGBJFJNGIGLPJO> ContinueWith<NMEFOGBJFJNGIGLPJO>(Func<PAPGFFIAEPDMAOFCHH<NMEFOGBJFJNGIGLPJO>> transformFunc, Func<string, PAPGFFIAEPDMAOFCHH<NMEFOGBJFJNGIGLPJO>> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0000685E File Offset: 0x00004A5E
		public FFACMGPJKHNBKLCJEK ContinueWith(Func<FFACMGPJKHNBKLCJEK> transformFunc, Func<string, FFACMGPJKHNBKLCJEK> transformErrorFunc = null)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x0000685E File Offset: 0x00004A5E
		public PAPGFFIAEPDMAOFCHH<PBKBNLFENIODBHFNDB> Transform<PBKBNLFENIODBHFNDB>(Func<PBKBNLFENIODBHFNDB> transformFunc)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x00006880 File Offset: 0x00004A80
		FFACMGPJKHNBKLCJEK FFACMGPJKHNBKLCJEK.TransformError(Func<string, string> transformFunc)
		{
			return this.TransformError(transformFunc);
		}
	}
}
