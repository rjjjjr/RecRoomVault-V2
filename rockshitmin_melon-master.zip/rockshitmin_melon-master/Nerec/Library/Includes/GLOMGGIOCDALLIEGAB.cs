﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x0200017D RID: 381
	public class GLOMGGIOCDALLIEGAB : Attribute
	{
	}
}
