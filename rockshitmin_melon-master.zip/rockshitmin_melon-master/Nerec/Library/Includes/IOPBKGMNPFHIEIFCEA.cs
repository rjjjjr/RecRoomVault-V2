﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000168 RID: 360
	[GLOMGGIOCDALLIEGAB]
	public interface IOPBKGMNPFHIEIFCEA
	{
		// Token: 0x0600060D RID: 1549
		object get_Current();

		// Token: 0x0600060E RID: 1550
		bool MoveNext();

		// Token: 0x0600060F RID: 1551
		void Reset();
	}
}
