﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000167 RID: 359
	public static class JELGILABEGAPMCJHFF
	{
		// Token: 0x0600060C RID: 1548 RVA: 0x0000643A File Offset: 0x0000463A
		public static HKLDGGMCANEIPNDPIB LocalPlayer()
		{
			return JELGILABEGAPMCJHFF._localPlayer = HKLDGGMCANEIPNDPIB.get_LocalPlayer();
		}

		// Token: 0x04000388 RID: 904
		private static HKLDGGMCANEIPNDPIB _localPlayer;
	}
}
