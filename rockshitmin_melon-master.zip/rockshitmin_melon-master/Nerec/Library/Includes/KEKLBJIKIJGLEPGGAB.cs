﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000172 RID: 370
	[GLOMGGIOCDALLIEGAB]
	public interface KEKLBJIKIJGLEPGGAB : FKEMNDNPHAGJKEFHKN
	{
		// Token: 0x06000642 RID: 1602
		int get_ViewId();
	}
}
