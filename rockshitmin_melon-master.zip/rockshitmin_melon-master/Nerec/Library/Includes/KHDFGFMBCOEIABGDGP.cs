﻿using System;
using UnityEngine;

namespace Nerec.Library.Includes
{
	// Token: 0x0200016F RID: 367
	[GLOMGGIOCDALLIEGAB]
	public class KHDFGFMBCOEIABGDGP
	{
		// Token: 0x06000639 RID: 1593 RVA: 0x00006677 File Offset: 0x00004877
		public KHDFGFMBCOEIABGDGP(Object o)
		{
			this._object = o;
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x00006686 File Offset: 0x00004886
		public string get_Name()
		{
			return this._object.name;
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x00006693 File Offset: 0x00004893
		public HideFlags get_HideFlags()
		{
			return this._object.hideFlags;
		}

		// Token: 0x0400038E RID: 910
		private Object _object;
	}
}
