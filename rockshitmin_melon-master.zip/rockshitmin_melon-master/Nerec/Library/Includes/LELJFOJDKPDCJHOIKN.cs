﻿using System;
using Il2Cpp;

namespace Nerec.Library.Includes
{
	// Token: 0x02000177 RID: 375
	public static class LELJFOJDKPDCJHOIKN
	{
		// Token: 0x0600065B RID: 1627 RVA: 0x000067C1 File Offset: 0x000049C1
		public static GDHIDEPCCBEBPAPBBK ToNative(this LKFKEMBCBJC player)
		{
			return new GDHIDEPCCBEBPAPBBK(player);
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x000067C9 File Offset: 0x000049C9
		public static LKFKEMBCBJC ToIl2cpp(this GDHIDEPCCBEBPAPBBK player)
		{
			return player.PLOFKGBIGLNOJJKGNI;
		}
	}
}
