﻿using System;
using System.Collections.Generic;

namespace Nerec.Library.Includes
{
	// Token: 0x02000174 RID: 372
	[GLOMGGIOCDALLIEGAB]
	public interface MICKGCLEMINKBHGPHG
	{
		// Token: 0x06000648 RID: 1608
		int get_ActorNumber();

		// Token: 0x06000649 RID: 1609
		bool get_IsLocal();

		// Token: 0x0600064A RID: 1610
		IDictionary<object, object> get_CustomProperties();

		// Token: 0x0600064B RID: 1611
		string get_NickName();

		// Token: 0x0600064C RID: 1612
		int get_RecNetAccountId();

		// Token: 0x0600064D RID: 1613
		bool get_IsBroadcasted();
	}
}
