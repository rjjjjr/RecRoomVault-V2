﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x02000169 RID: 361
	[GLOMGGIOCDALLIEGAB]
	public interface OOIBBJFODDICJJPBMO<out T> : IOPBKGMNPFHIEIFCEA
	{
		// Token: 0x06000610 RID: 1552
		T get_Current();
	}
}
