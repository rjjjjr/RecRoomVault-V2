﻿using System;

namespace Nerec.Library.Includes
{
	// Token: 0x0200017E RID: 382
	[GLOMGGIOCDALLIEGAB]
	public static class PBKMLIAADEKIJOKEKA
	{
		// Token: 0x06000673 RID: 1651 RVA: 0x00006857 File Offset: 0x00004A57
		public static FFACMGPJKHNBKLCJEK LocalRequestGiftPackage(GNECJDNDCMFCBAKMBK context, GNECJDNDCMFCBAKMBK? alternateContext, bool isGameGift, string message)
		{
			return new FBAGIDFKLGJMONIPNA();
		}
	}
}
