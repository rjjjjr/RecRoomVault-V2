﻿using System;

namespace Nerec.Library
{
	// Token: 0x02000142 RID: 322
	public static class KDMLJLIJNANBIKHKCO
	{
		// Token: 0x040002BD RID: 701
		public static readonly string CheatManagerPath = "GameRoot/(Startup)(Clone)/Core Systems/[CheatManager]";

		// Token: 0x040002BE RID: 702
		public static readonly string EacManagerPath = "GameRoot/(Startup)(Clone)/Core Systems/[EACManager]";

		// Token: 0x040002BF RID: 703
		public static readonly uint EconomyMenuTabId = 1U;

		// Token: 0x040002C0 RID: 704
		public static readonly uint PlayerModsMenuTabId = 10U;

		// Token: 0x040002C1 RID: 705
		public static readonly uint WatchModsMenuTabId = 20U;

		// Token: 0x040002C2 RID: 706
		public static readonly uint WorldModsMenuTabId = 30U;
	}
}
