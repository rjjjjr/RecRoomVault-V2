﻿using System;

namespace Nerec.Library
{
	// Token: 0x0200013D RID: 317
	public class KHPHJIOMCFBENNMEKI
	{
		// Token: 0x040002B2 RID: 690
		public float period;

		// Token: 0x040002B3 RID: 691
		public Action action;

		// Token: 0x040002B4 RID: 692
		public float hz;

		// Token: 0x040002B5 RID: 693
		public float current;
	}
}
