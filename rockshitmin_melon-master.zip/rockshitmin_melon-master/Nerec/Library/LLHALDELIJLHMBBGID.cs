﻿using System;

namespace Nerec.Library
{
	// Token: 0x0200013F RID: 319
	public enum LLHALDELIJLHMBBGID
	{
		// Token: 0x040002B8 RID: 696
		OneFrame,
		// Token: 0x040002B9 RID: 697
		Update,
		// Token: 0x040002BA RID: 698
		LateUpdate,
		// Token: 0x040002BB RID: 699
		FixedUpdate,
		// Token: 0x040002BC RID: 700
		UpdateHz
	}
}
