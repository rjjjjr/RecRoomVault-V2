﻿using System;

namespace Nerec.Library
{
	// Token: 0x02000141 RID: 321
	public sealed class ODCFJDIDECFCPJJAAL : Attribute
	{
	}
}
