﻿using System;

namespace Nerec.Library.ServerOverride
{
	// Token: 0x02000165 RID: 357
	public class HCHDIFPAJJEJBMOJCK
	{
		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x000063C7 File Offset: 0x000045C7
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x000063CF File Offset: 0x000045CF
		public string HPEJMHAEPLEIDPGMAH { get; set; }

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x000063D8 File Offset: 0x000045D8
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x000063E0 File Offset: 0x000045E0
		public string PHGLHCEFFBNOPEILFC { get; set; }

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x000063E9 File Offset: 0x000045E9
		// (set) Token: 0x06000607 RID: 1543 RVA: 0x000063F1 File Offset: 0x000045F1
		public bool HMDFGEIJPBJEILLFKK { get; set; }
	}
}
