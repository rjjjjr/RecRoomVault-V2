﻿using System;

namespace Nerec.Library.ServerOverride
{
	// Token: 0x02000164 RID: 356
	public class NGBFHGHBKJEJMDJLKI
	{
		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060005F9 RID: 1529 RVA: 0x00006383 File Offset: 0x00004583
		// (set) Token: 0x060005FA RID: 1530 RVA: 0x0000638B File Offset: 0x0000458B
		public string AHBEAICOBCFJPMOEHD { get; set; }

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060005FB RID: 1531 RVA: 0x00006394 File Offset: 0x00004594
		// (set) Token: 0x060005FC RID: 1532 RVA: 0x0000639C File Offset: 0x0000459C
		public string LMNAIEMFKENOIOPKDB { get; set; }

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060005FD RID: 1533 RVA: 0x000063A5 File Offset: 0x000045A5
		// (set) Token: 0x060005FE RID: 1534 RVA: 0x000063AD File Offset: 0x000045AD
		public string ONEPIPHGCOPDJGIFCN { get; set; }

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060005FF RID: 1535 RVA: 0x000063B6 File Offset: 0x000045B6
		// (set) Token: 0x06000600 RID: 1536 RVA: 0x000063BE File Offset: 0x000045BE
		public string KJKJGIPHAIALDKIBEJ { get; set; }
	}
}
