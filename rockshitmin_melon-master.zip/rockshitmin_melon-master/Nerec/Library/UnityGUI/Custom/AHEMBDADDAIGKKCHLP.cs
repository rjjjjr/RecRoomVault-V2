﻿using System;

namespace Nerec.Library.UnityGUI.Custom
{
	// Token: 0x0200015B RID: 347
	public enum AHEMBDADDAIGKKCHLP
	{
		// Token: 0x04000362 RID: 866
		Normal,
		// Token: 0x04000363 RID: 867
		Fixed,
		// Token: 0x04000364 RID: 868
		Infinite
	}
}
