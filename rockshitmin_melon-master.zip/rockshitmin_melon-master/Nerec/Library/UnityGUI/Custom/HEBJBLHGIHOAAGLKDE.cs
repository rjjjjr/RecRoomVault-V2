﻿using System;

namespace Nerec.Library.UnityGUI.Custom
{
	// Token: 0x0200015C RID: 348
	public enum HEBJBLHGIHOAAGLKDE
	{
		// Token: 0x04000366 RID: 870
		WithRecoil,
		// Token: 0x04000367 RID: 871
		WithoutRecoil
	}
}
