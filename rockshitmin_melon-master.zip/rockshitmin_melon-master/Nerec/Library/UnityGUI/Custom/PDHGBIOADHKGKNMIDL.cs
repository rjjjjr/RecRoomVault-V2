﻿using System;

namespace Nerec.Library.UnityGUI.Custom
{
	// Token: 0x0200015A RID: 346
	public enum PDHGBIOADHKGKNMIDL
	{
		// Token: 0x0400035F RID: 863
		ScreenMode,
		// Token: 0x04000360 RID: 864
		VR
	}
}
