﻿using System;

namespace Nerec.Library.UnityGUI
{
	// Token: 0x02000147 RID: 327
	public abstract class FPILPOPAMHBJOIIGKM
	{
		// Token: 0x17000032 RID: 50
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x00005EB4 File Offset: 0x000040B4
		// (set) Token: 0x0600057D RID: 1405 RVA: 0x00005EBC File Offset: 0x000040BC
		public object FOLLPAJPCGIENBNKHM { get; set; }

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x0600057E RID: 1406
		public abstract PIMOHOCBLANOOCHIOK EOMFDGFGPJHLCIMDMF { get; }
	}
}
