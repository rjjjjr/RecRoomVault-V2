﻿using System;
using UnityEngine;

namespace Nerec.Library.UnityGUI
{
	// Token: 0x02000151 RID: 337
	public struct NBKBLKAEBNKKNKKHIN
	{
		// Token: 0x0400033B RID: 827
		public uint tabId;

		// Token: 0x0400033C RID: 828
		public string title;

		// Token: 0x0400033D RID: 829
		public Rect size;

		// Token: 0x0400033E RID: 830
		public Action<int> drawAction;
	}
}
