﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using MelonLoader;
using Nerec;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany(null)]
[assembly: AssemblyProduct("Nerec")]
[assembly: AssemblyCopyright("Created by nullable")]
[assembly: AssemblyTrademark(null)]
[assembly: AssemblyFileVersion("1.0.0")]
[assembly: MelonInfo(typeof(Entry), "Nerec", "1.0.0", "nullable", null)]
[assembly: MelonColor]
[assembly: MelonGame(null, null)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
