﻿using System;

namespace Utf8Json
{
	// Token: 0x02000005 RID: 5
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
	public sealed class CBDAFKBMADIJACENAE : Attribute
	{
	}
}
