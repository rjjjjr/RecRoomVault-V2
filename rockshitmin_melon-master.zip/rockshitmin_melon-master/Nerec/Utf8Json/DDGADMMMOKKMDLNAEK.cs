﻿using System;

namespace Utf8Json
{
	// Token: 0x02000009 RID: 9
	public interface DDGADMMMOKKMDLNAEK
	{
	}
}
