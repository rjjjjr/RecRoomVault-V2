﻿using System;

namespace Utf8Json
{
	// Token: 0x02000003 RID: 3
	[AttributeUsage(AttributeTargets.Constructor, AllowMultiple = false, Inherited = true)]
	public class FFEIDIOIJPCAMMEPMJ : Attribute
	{
	}
}
