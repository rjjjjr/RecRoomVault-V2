﻿using System;

namespace Utf8Json
{
	// Token: 0x0200000A RID: 10
	public interface FLGKBGGCEAHKIBEKBN<T> : DDGADMMMOKKMDLNAEK
	{
		// Token: 0x06000013 RID: 19
		void Serialize(ref BJLLMLPIIIPIEPLCJH writer, T value, LMCMANMFGJGJFPNBEN formatterResolver);

		// Token: 0x06000014 RID: 20
		T Deserialize(ref BPIPCPJELFMIKDNCFG reader, LMCMANMFGJGJFPNBEN formatterResolver);
	}
}
