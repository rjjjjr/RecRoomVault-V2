﻿using System;
using Utf8Json.Internal;

namespace Utf8Json.Formatters.Internal
{
	// Token: 0x02000137 RID: 311
	internal static class CALNGPEONCMKOFIDMF
	{
		// Token: 0x0400029E RID: 670
		internal static readonly byte[][] groupingName = new byte[][]
		{
			BJLLMLPIIIPIEPLCJH.GetEncodedPropertyNameWithBeginObject("Key"),
			BJLLMLPIIIPIEPLCJH.GetEncodedPropertyNameWithPrefixValueSeparator("Elements")
		};

		// Token: 0x0400029F RID: 671
		internal static readonly CBCBOOCAFACEIEKOLL groupingAutomata = new CBCBOOCAFACEIEKOLL
		{
			{
				BJLLMLPIIIPIEPLCJH.GetEncodedPropertyNameWithoutQuotation("Key"),
				0
			},
			{
				BJLLMLPIIIPIEPLCJH.GetEncodedPropertyNameWithoutQuotation("Elements"),
				1
			}
		};
	}
}
