﻿using System;

namespace Utf8Json
{
	// Token: 0x02000004 RID: 4
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
	public sealed class GLJJNJDFMBPNMFKPAP : Attribute
	{
		// Token: 0x04000003 RID: 3
		public string Name;
	}
}
