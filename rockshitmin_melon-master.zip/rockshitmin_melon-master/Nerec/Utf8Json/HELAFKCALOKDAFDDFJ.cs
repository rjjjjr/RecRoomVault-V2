﻿using System;

namespace Utf8Json
{
	// Token: 0x02000006 RID: 6
	[AttributeUsage(AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
	public sealed class HELAFKCALOKDAFDDFJ : Attribute
	{
		// Token: 0x04000004 RID: 4
		public string Value;
	}
}
