﻿using System;

namespace Utf8Json
{
	// Token: 0x0200000C RID: 12
	public static class HIKJNEKCCKKNCPDMLJ
	{
		// Token: 0x06000017 RID: 23 RVA: 0x000068E8 File Offset: 0x00004AE8
		public static string ToJsonString<KPGLBKMPOJLKKICJLP>(this FLGKBGGCEAHKIBEKBN<KPGLBKMPOJLKKICJLP> formatter, KPGLBKMPOJLKKICJLP value, LMCMANMFGJGJFPNBEN formatterResolver)
		{
			BJLLMLPIIIPIEPLCJH bjllmlpiiipieplcjh = default(BJLLMLPIIIPIEPLCJH);
			formatter.Serialize(ref bjllmlpiiipieplcjh, value, formatterResolver);
			return bjllmlpiiipieplcjh.ToString();
		}
	}
}
