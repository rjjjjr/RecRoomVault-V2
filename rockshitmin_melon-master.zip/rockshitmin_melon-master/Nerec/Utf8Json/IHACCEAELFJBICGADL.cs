﻿using System;

namespace Utf8Json
{
	// Token: 0x0200001C RID: 28
	public enum IHACCEAELFJBICGADL : byte
	{
		// Token: 0x04000023 RID: 35
		None,
		// Token: 0x04000024 RID: 36
		BeginObject,
		// Token: 0x04000025 RID: 37
		EndObject,
		// Token: 0x04000026 RID: 38
		BeginArray,
		// Token: 0x04000027 RID: 39
		EndArray,
		// Token: 0x04000028 RID: 40
		Number,
		// Token: 0x04000029 RID: 41
		String,
		// Token: 0x0400002A RID: 42
		True,
		// Token: 0x0400002B RID: 43
		False,
		// Token: 0x0400002C RID: 44
		Null,
		// Token: 0x0400002D RID: 45
		ValueSeparator,
		// Token: 0x0400002E RID: 46
		NameSeparator
	}
}
