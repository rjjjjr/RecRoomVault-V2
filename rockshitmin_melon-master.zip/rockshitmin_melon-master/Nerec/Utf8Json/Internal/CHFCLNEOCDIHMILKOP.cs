﻿using System;
using System.Text;

namespace Utf8Json.Internal
{
	// Token: 0x020000AA RID: 170
	internal static class CHFCLNEOCDIHMILKOP
	{
		// Token: 0x04000198 RID: 408
		public static readonly Encoding UTF8 = new UTF8Encoding(false);
	}
}
