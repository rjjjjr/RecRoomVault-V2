﻿using System;
using System.Runtime.InteropServices;

namespace Utf8Json.Internal.DoubleConversion
{
	// Token: 0x020000C1 RID: 193
	[StructLayout(LayoutKind.Explicit, Pack = 1)]
	internal struct BMLEBHBCBKLKGECLOF
	{
		// Token: 0x040001EA RID: 490
		[FieldOffset(0)]
		public double d;

		// Token: 0x040001EB RID: 491
		[FieldOffset(0)]
		public ulong u64;
	}
}
