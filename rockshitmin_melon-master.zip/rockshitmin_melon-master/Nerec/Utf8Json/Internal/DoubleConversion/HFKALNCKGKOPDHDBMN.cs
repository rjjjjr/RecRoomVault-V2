﻿using System;
using System.Runtime.InteropServices;

namespace Utf8Json.Internal.DoubleConversion
{
	// Token: 0x020000C2 RID: 194
	[StructLayout(LayoutKind.Explicit, Pack = 1)]
	internal struct HFKALNCKGKOPDHDBMN
	{
		// Token: 0x040001EC RID: 492
		[FieldOffset(0)]
		public float f;

		// Token: 0x040001ED RID: 493
		[FieldOffset(0)]
		public uint u32;
	}
}
