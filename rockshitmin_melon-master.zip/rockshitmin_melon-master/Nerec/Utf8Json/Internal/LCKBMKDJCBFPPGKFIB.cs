﻿using System;

namespace Utf8Json.Internal
{
	// Token: 0x02000096 RID: 150
	internal sealed class LCKBMKDJCBFPPGKFIB : FLKLOHJCFNJIBPBADP<byte>
	{
		// Token: 0x060001F5 RID: 501 RVA: 0x00003D1B File Offset: 0x00001F1B
		public LCKBMKDJCBFPPGKFIB(int bufferLength) : base(bufferLength)
		{
		}

		// Token: 0x04000146 RID: 326
		public static readonly LCKBMKDJCBFPPGKFIB Default = new LCKBMKDJCBFPPGKFIB(65535);
	}
}
