﻿using System;

namespace Utf8Json
{
	// Token: 0x0200000D RID: 13
	public interface LMCMANMFGJGJFPNBEN
	{
		// Token: 0x06000018 RID: 24
		FLGKBGGCEAHKIBEKBN<T> GetFormatter<T>();
	}
}
