﻿using System;

namespace Utf8Json
{
	// Token: 0x0200000F RID: 15
	public class NODLCKMOHBBPIMOOAB : Exception
	{
		// Token: 0x0600001B RID: 27 RVA: 0x000023F0 File Offset: 0x000005F0
		public NODLCKMOHBBPIMOOAB(string message) : base(message)
		{
		}
	}
}
