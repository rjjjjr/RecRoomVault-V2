﻿using System;

namespace Utf8Json
{
	// Token: 0x02000007 RID: 7
	// (Invoke) Token: 0x0600000C RID: 12
	public delegate void OJFAAEDNBNAMBCPLED<T>(ref BJLLMLPIIIPIEPLCJH writer, T value, LMCMANMFGJGJFPNBEN resolver);
}
