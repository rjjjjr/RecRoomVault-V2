﻿using System;

namespace Utf8Json
{
	// Token: 0x0200000B RID: 11
	public interface OJKBDJBONOCKIDIKGG<T>
	{
		// Token: 0x06000015 RID: 21
		void SerializeToPropertyName(ref BJLLMLPIIIPIEPLCJH writer, T value, LMCMANMFGJGJFPNBEN formatterResolver);

		// Token: 0x06000016 RID: 22
		T DeserializeFromPropertyName(ref BPIPCPJELFMIKDNCFG reader, LMCMANMFGJGJFPNBEN formatterResolver);
	}
}
