﻿using System;

namespace Utf8Json
{
	// Token: 0x02000008 RID: 8
	// (Invoke) Token: 0x06000010 RID: 16
	public delegate T PCPKEIOPEDBCBJAJCJ<T>(ref BPIPCPJELFMIKDNCFG reader, LMCMANMFGJGJFPNBEN resolver);
}
