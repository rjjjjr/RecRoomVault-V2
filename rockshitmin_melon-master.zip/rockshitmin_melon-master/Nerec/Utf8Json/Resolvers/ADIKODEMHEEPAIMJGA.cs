﻿using System;
using Utf8Json.Resolvers.Internal;

namespace Utf8Json.Resolvers
{
	// Token: 0x02000029 RID: 41
	public static class ADIKODEMHEEPAIMJGA
	{
		// Token: 0x0400004E RID: 78
		public static readonly LMCMANMFGJGJFPNBEN Default = ELMHKABIGCEAPECEEE.Instance;

		// Token: 0x0400004F RID: 79
		public static readonly LMCMANMFGJGJFPNBEN UnderlyingValue = MJMIEGBINDDBGFDGKP.Instance;
	}
}
