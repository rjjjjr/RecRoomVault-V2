﻿using System;

namespace Utf8Json.Resolvers.Internal
{
	// Token: 0x02000064 RID: 100
	internal static class JEDCOLEOGMFNOGKCIB
	{
		// Token: 0x040000FB RID: 251
		internal static readonly LMCMANMFGJGJFPNBEN[] CompositeResolverBase = new LMCMANMFGJGJFPNBEN[]
		{
			FAHOODOKOCCDBINONC.Instance,
			ADIKODEMHEEPAIMJGA.Default,
			AANMMDHFHAHOGAALHF.Instance,
			KNNODPPCNHCIHAIDAO.Instance
		};
	}
}
