﻿using System;

namespace Utf8Json.Resolvers.Internal
{
	// Token: 0x0200005D RID: 93
	// (Invoke) Token: 0x0600017F RID: 383
	internal delegate void NOICGFGCECKIDDMBKC<T>(byte[][] stringByteKeysField, object[] customFormatters, ref BJLLMLPIIIPIEPLCJH writer, T value, LMCMANMFGJGJFPNBEN resolver);
}
