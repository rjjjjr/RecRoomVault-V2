﻿using System;

namespace Utf8Json.Resolvers.Internal
{
	// Token: 0x0200005E RID: 94
	// (Invoke) Token: 0x06000183 RID: 387
	internal delegate T POONOLDLJBGBIPLHLJ<T>(object[] customFormatters, ref BPIPCPJELFMIKDNCFG reader, LMCMANMFGJGJFPNBEN resolver);
}
