> # RR Cleaner
This was my C# learning project. Program attempts to delete all the garbage the game doesn't delete during it's uninstallation.